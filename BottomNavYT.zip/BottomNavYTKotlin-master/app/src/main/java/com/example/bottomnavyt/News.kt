package com.example.bottomnavyt

data class News(var titleImage : Int,var heading : String)
